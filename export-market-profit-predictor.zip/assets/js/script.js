(function($){
    function simplePredict(data, commodity) {
        let monthly = {};
        data.forEach(r=>{
            if(!r) return;
            const c = (r.commodity || r.Commodity || '').toLowerCase();
            if(c.indexOf(commodity)===-1 && !(commodity==='milk' && c.indexOf('milk')!==-1)) return;
            const date = r.date || r.Date || r.DATE || '';
            const price = parseFloat(r.price || r.Price || r.PRICE || r.value || 0) || 0;
            if(!date) return;
            const m = date.slice(0,7);
            monthly[m] = monthly[m] || [];
            monthly[m].push(price);
        });
        let rows = [];
        Object.keys(monthly).sort().forEach(m=>{
            const arr = monthly[m];
            const avg = arr.reduce((a,b)=>a+b,0)/arr.length;
            rows.push({month:m,avg:parseFloat(avg.toFixed(2))});
        });
        if(rows.length===0){
            const now = new Date();
            for(let i=0;i<12;i++){
                const d = new Date(now.getFullYear(), now.getMonth()+i, 1);
                const m = d.toISOString().slice(0,7);
                const base = commodity==='corn'?5.5: commodity==='soy'?11.2: commodity==='milk'?3.8:10;
                const val = +(base + Math.sin(i/2)*0.3 + Math.random()*0.2).toFixed(2);
                rows.push({month:m,avg:val});
            }
        }
        return rows;
    }

    function computeBestMonths(rows) {
        const sorted = rows.slice().sort((a,b)=>b.avg-a.avg);
        return sorted.slice(0,3).map(r=>r.month);
    }

    function generateCSV(rows, commodity, quantity) {
        let csv = 'month,avg_price,estimated_revenue\n';
        rows.forEach(r=>{
            const rev = (r.avg * quantity).toFixed(2);
            csv += `${r.month},${r.avg},${rev}\n`;
        });
        return csv;
    }

    function downloadBlob(filename, content, mime) {
        const blob = new Blob([content], {type: mime || 'text/csv'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    }

    $(document).ready(function(){
        const $app = $('#empp-app');
        const raw = $app.data('usda') || '[]';
        let data = [];
        try { data = JSON.parse(raw); } catch(e){ data = raw; }
        $('#empp-run').on('click', function(e){
            e.preventDefault();
            const commodity = $('#empp-commodity').val();
            const qty = parseFloat($('#empp-quantity').val()) || 1;
            const rows = simplePredict(data, commodity);
            const best = computeBestMonths(rows);
            $('#empp-summary').html('<strong>Best months to sell:</strong> ' + best.join(', '));
            let html = '<table class="empp-table"><thead><tr><th>Month</th><th>Avg Price</th><th>Estimated Revenue</th></tr></thead><tbody>';
            rows.forEach(r=>{
                html += `<tr><td>${r.month}</td><td>${r.avg}</td><td>${(r.avg*qty).toFixed(2)}</td></tr>`;
            });
            html += '</tbody></table>';
            $('#empp-table-wrap').html(html);
            $('#empp-results').show();
            $('#empp-export-csv').off('click').on('click',function(){
                const csv = generateCSV(rows, commodity, qty);
                downloadBlob('empp_report_'+commodity+'.csv', csv, 'text/csv');
            });
            $('#empp-export-pdf').off('click').on('click',function(){
                try {
                    const { jsPDF } = window.jspdf;
                    const doc = new jsPDF();
                    doc.setFontSize(12);
                    doc.text('Export Market Profit Predictor — Report', 10, 10);
                    doc.text('Commodity: ' + commodity, 10, 18);
                    doc.text('Quantity: ' + qty, 10, 26);
                    let y = 36;
                    doc.setFontSize(10);
                    doc.text('Month    Avg_Price    Estimated_Revenue', 10, y);
                    y += 6;
                    rows.forEach(r=>{
                        const line = `${r.month}    ${r.avg}    ${(r.avg*qty).toFixed(2)}`;
                        doc.text(line, 10, y);
                        y += 6;
                        if(y > 280) { doc.addPage(); y = 10; }
                    });
                    doc.save('empp_report_'+commodity+'.pdf');
                } catch(err){
                    alert('PDF export failed: ' + err);
                }
            });
        });
    });
})(jQuery);
