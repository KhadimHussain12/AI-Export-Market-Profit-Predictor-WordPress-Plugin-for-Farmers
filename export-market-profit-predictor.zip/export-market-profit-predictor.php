<?php
/**
 * Plugin Name: Export Market Profit Predictor
 * Description: Predicts best months to sell corn, soy and milk using uploaded USDA data. Provides CSV and PDF export on client side.
 * Version: 1.0
 * Author: ChatGPT
 * Text Domain: export-market-profit-predictor
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define('EMPP_DIR', plugin_dir_path(__FILE__));
define('EMPP_URL', plugin_dir_url(__FILE__));

function empp_enqueue_assets() {
    wp_enqueue_style('empp-style', EMPP_URL . 'assets/css/style.css', array(), '1.0');
    wp_enqueue_script('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);
    wp_enqueue_script('empp-script', EMPP_URL . 'assets/js/script.js', array('jquery','jspdf'), '1.0', true);
    wp_localize_script('empp-script', 'empp_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('empp_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'empp_enqueue_assets');
add_action('admin_enqueue_scripts', 'empp_enqueue_assets');

function empp_admin_menu() {
    add_menu_page('Market Predictor', 'Market Predictor', 'manage_options', 'empp_admin', 'empp_admin_page', 'dashicons-chart-line', 30);
}
add_action('admin_menu', 'empp_admin_menu');

function empp_admin_page() {
    if (!current_user_can('manage_options')) return;
    if ( isset($_POST['empp_upload']) && check_admin_referer('empp_upload_action','empp_upload_nonce') ) {
        if (!empty($_FILES['empp_csv']['tmp_name'])) {
            $uploaded = wp_handle_upload($_FILES['empp_csv'], array('test_form'=>false));
            if (!isset($uploaded['error'])) {
                $path = $uploaded['file'];
                $rows = array();
                if (($handle = fopen($path, "r")) !== FALSE) {
                    $headers = fgetcsv($handle);
                    while (($data = fgetcsv($handle)) !== FALSE) {
                        $row = array();
                        foreach ($headers as $i => $h) $row[$h] = $data[$i] ?? '';
                        $rows[] = $row;
                    }
                    fclose($handle);
                }
                update_option('empp_usda_data', $rows);
                echo '<div class="notice notice-success is-dismissible"><p>USDA CSV uploaded and parsed. Rows: '.count($rows).'</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Upload error: '.$uploaded['error'].'</p></div>';
            }
        }
    }

    $data = get_option('empp_usda_data', array());
    ?>
    <div class="wrap">
        <h1>Export Market Profit Predictor — Admin</h1>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('empp_upload_action','empp_upload_nonce'); ?>
            <p><label>Upload USDA CSV (headers like date,commodity,price):</label><br/>
            <input type="file" name="empp_csv" accept=".csv" required></p>
            <p><input type="submit" name="empp_upload" class="button button-primary" value="Upload & Parse CSV"></p>
        </form>

        <h2>Stored data preview</h2>
        <p>Rows stored: <?php echo count($data); ?></p>
        <?php if (!empty($data)) : ?>
            <table class="widefat fixed">
                <thead><tr>
                <?php foreach (array_keys((array)$data[0]) as $h) echo '<th>'.esc_html($h).'</th>'; ?>
                </tr></thead>
                <tbody>
                <?php foreach ($data as $r) {
                    echo '<tr>';
                    foreach ($r as $c) echo '<td>'.esc_html($c).'</td>';
                    echo '</tr>';
                } ?>
                </tbody>
            </table>
        <?php endif; ?>
        <p>Shortcode to show predictor UI on any page: <code>[empp_predictor]</code></p>
    </div>
    <?php
}

function empp_predictor_shortcode($atts) {
    $data = get_option('empp_usda_data', array());
    ob_start();
    ?>
    <div id="empp-app" class="empp-container" data-usda='<?php echo esc_attr(wp_json_encode($data)); ?>'>
        <h2>Export Market Profit Predictor</h2>
        <p>Pick commodity and a sample quantity to get predicted best months to sell.</p>
        <div class="empp-form">
            <label>Commodity
                <select id="empp-commodity">
                    <option value="corn">Corn</option>
                    <option value="soy">Soy</option>
                    <option value="milk">Milk</option>
                </select>
            </label>
            <label>Quantity (units)
                <input type="number" id="empp-quantity" value="100">
            </label>
            <button id="empp-run" class="button">Run Prediction</button>
        </div>
        <div id="empp-results" style="display:none;">
            <h3>Prediction</h3>
            <div id="empp-summary"></div>
            <div id="empp-table-wrap"></div>
            <div class="empp-exports">
                <button id="empp-export-csv" class="button">Export CSV</button>
                <button id="empp-export-pdf" class="button">Download PDF</button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('empp_predictor','empp_predictor_shortcode');
?>